import AdminLayout from "./components/AdminLayout";
import UserLayout from "./components/UserLayout";
import { BrowserRouter, Routes, Route } from "react-router-dom";

// Home
import Home from "./components/user/pages/Home";
import Menu from "./components/user/pages/Menu";
import About from "./components/user/pages/About";
import Contact from "./components/user/pages/Contact";

// Admin
import Dashboard from "./components/admin/pages/Dashboard";
import Category from "./components/admin/pages/Category";
import AddCategory from "./components/admin/pages/addCategory";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>

          {/* client routes */}
          <Route path="/" element={<UserLayout />}>
            <Route index element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/menu" element={<Menu />} />
          </Route>

          {/* admin routes */}
          <Route path="admin" element={<AdminLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="category" element={<Category />} />
            <Route path="category-add" element={<AddCategory />} />
          </Route>

          {/* auth routes */}
          {/* <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Registration />} /> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
