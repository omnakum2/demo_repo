import React from "react";
import { Outlet } from "react-router-dom";
import AdminHeader from "../components/admin/Header";

function AdminLayout() {
  return (
    <div>
      <AdminHeader />
      <main id="main" className="main">
        <Outlet />
      </main>
    </div>
  );
}

export default AdminLayout;
