import React from "react";
import { Link } from "react-router-dom";

function addCategory() {
  return (
    <div>
      <div className="pagetitle">
        Add Categories
        <Link className="btn btn-dark btn-sm float-end" to="/admin/category">
          <span>Back</span>
        </Link>
      </div>
      <hr />
    </div>
  );
}

export default addCategory;
